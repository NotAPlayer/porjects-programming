USE world;

SELECT Continent, COUNT(*) AS CountriesOver70
FROM Country
WHERE LifeExpectancy > 70
GROUP BY Continent;

SELECT Continent, COUNT(*) AS CountriesBetween60And70
FROM Country
WHERE LifeExpectancy BETWEEN 60 AND 70
GROUP BY Continent;


SELECT Name, LifeExpectancy
FROM Country
WHERE LifeExpectancy > 75;


SELECT COUNT(*) AS CountriesOver75
FROM Country
WHERE LifeExpectancy < 40;


SELECT Name, Population
FROM Country
ORDER BY Population DESC
LIMIT 10;


SELECT SUM(Population) AS WorldPopulation
FROM Country;


SELECT Continent, SUM(Population) AS TotalPopulation
FROM Country
GROUP BY Continent
HAVING SUM(Population) > 500000000;

SELECT Continent,
COUNT(*) AS CountryCount,
SUM(Population) AS TotalPopulation,
AVG(LifeExpectancy) AS AverageLifeExpectancy
FROM Country
GROUP BY Continent
HAVING AVG(LifeExpectancy) < 71;


