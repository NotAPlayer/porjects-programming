SELECT 
    country.Name AS country, 
    COUNT(city.ID) AS number_of_cities
FROM country
LEFT JOIN city ON country.Code = city.CountryCode
GROUP BY country.Name;

SELECT 
    Language,
    GROUP_CONCAT(country.Name SEPARATOR ', ') AS countries,
    COUNT(*) AS number_of_countries
FROM world.country
JOIN 
countrylanguage ON country.code = countrylanguage.CountryCode
GROUP BY Language;

SELECT cl.Language, COUNT(cl.CountryCode) AS total_countries, cl.IsOfficial
FROM CountryLanguage cl
WHERE cl.IsOfficial = 'T'
GROUP BY cl.Language, cl.IsOfficial
ORDER BY cl.Language;
    
SELECT 
    country.Continent,
    COUNT(city.ID) AS CityCount,
    AVG(city.Population) AS AvgCityPopulation
FROM city
JOIN country ON city.CountryCode = country.Code
GROUP BY country.Continent;


SELECT 
    cl.Language,
    SUM(c.Population * cl.Percentage / 100) AS Speakers
FROM countrylanguage cl
JOIN country c ON cl.CountryCode = c.Code
GROUP BY cl.Language
ORDER BY Speakers DESC;
